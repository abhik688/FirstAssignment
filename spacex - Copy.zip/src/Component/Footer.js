import React from 'react';


const footer = (props)=>{
    return(
        <div style={{textAlign:"center"}}>
            <p><strong>Developed by:</strong> Abhishek Kumar pandey</p>
        </div>
    )
}

export default footer;